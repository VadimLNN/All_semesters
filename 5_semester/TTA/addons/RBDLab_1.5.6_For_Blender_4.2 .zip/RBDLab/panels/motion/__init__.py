from .motion import QUICK_RIGIDBODIES_PT_ui

MOTION_UI = (
    QUICK_RIGIDBODIES_PT_ui,

)
