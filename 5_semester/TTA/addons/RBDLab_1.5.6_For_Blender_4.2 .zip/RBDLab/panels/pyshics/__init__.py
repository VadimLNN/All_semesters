from .main import RBD_PT_ui

PYSHICS_UI = (
    RBD_PT_ui,
)
