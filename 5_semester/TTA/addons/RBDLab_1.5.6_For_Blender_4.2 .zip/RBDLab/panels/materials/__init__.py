from .material import (
    MATERIALS_PT_ui,
    RBDLAB_PT_materials_properties
)
from .material_ui_ul_list import MAT_UL_work_group, MAT_UL_dynamic_materials

MATERIALS_UI = (
    RBDLAB_PT_materials_properties,
    MATERIALS_PT_ui,
    MAT_UL_work_group,
    MAT_UL_dynamic_materials
)
