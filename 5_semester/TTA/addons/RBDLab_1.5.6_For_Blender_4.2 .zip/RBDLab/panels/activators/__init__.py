from .activators import ACTIVATORS_PT_ui

ACTIVATORS_UI = (
    ACTIVATORS_PT_ui,
)
