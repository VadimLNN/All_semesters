from .collisions import COLLISIONS_PT_ui
from .collision_so_ui_ul_list import COLLISION_SO_UL_group

COLLISIONS_UI = (
    COLLISIONS_PT_ui,
    COLLISION_SO_UL_group,
)
