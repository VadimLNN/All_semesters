from .main import SMOKE_PT_ui

SMOKE_UI = (
    SMOKE_PT_ui,
)
