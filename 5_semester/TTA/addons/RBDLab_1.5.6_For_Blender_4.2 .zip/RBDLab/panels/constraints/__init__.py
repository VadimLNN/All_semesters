from .constraints import CONSTRAINTS_PT_ui
from .lists.work_group_list import CONST_UL_work_group
from .lists.const_group_list import CONST_UL_const_group


CONSTR_UI = (
    CONST_UL_work_group,
    CONST_UL_const_group,
    CONSTRAINTS_PT_ui,
)
