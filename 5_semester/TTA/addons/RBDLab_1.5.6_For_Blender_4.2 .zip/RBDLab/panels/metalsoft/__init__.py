from .metal import METAL_PT_ui

METAL_UI = (
    METAL_PT_ui,
)
