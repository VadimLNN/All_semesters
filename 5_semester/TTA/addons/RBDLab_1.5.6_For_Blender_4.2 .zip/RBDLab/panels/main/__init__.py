from . panel_manager import PanelManager, RBDLAB_PT_utils_dropdown

MAIN_UI = (
    RBDLAB_PT_utils_dropdown,
    PanelManager,
)
