from .rm_target_coll import RM_OT_target_coll_from_list
from .add_custom_collection import RBDLAB_OT_add_custom_collection

TARGET_COLLECTION_OPS = (
    RM_OT_target_coll_from_list,
    RBDLAB_OT_add_custom_collection
)
