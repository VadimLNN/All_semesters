from .motion import (
                        RBDLAB_OT_motion_set_kinematic,
                        RBDLAB_OT_motion_add_emitter,
                        RBDLAB_OT_motion_remove_emitter,
                        RBDLAB_OT_motion_convert_ps_to_rbd,
                        RBDLAB_OT_motion_rm_kinematic,
                        RBDLAB_OT_motion_offset,
                        RBDLAB_OT_motion_set_rbd,
                        RBDLAB_OT_motion_rm_rbd,
                    )

MOTION_OPS = (
    RBDLAB_OT_motion_set_kinematic,
    RBDLAB_OT_motion_add_emitter,
    RBDLAB_OT_motion_remove_emitter,
    RBDLAB_OT_motion_convert_ps_to_rbd,
    RBDLAB_OT_motion_rm_kinematic,
    RBDLAB_OT_motion_offset,
    RBDLAB_OT_motion_set_rbd,
    RBDLAB_OT_motion_rm_rbd,
)
