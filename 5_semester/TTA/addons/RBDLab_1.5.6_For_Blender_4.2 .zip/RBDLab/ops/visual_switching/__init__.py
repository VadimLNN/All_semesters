from .visual_switching import RBDLab_OT_visual_switching
from .restore import RBDLab_OT_visual_switching_restore

SWITCHING_OPS = (
    RBDLab_OT_visual_switching,
    RBDLab_OT_visual_switching_restore,
)
