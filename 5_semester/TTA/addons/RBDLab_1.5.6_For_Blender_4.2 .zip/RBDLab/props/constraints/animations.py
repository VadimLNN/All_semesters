from bpy.types import PropertyGroup
# from bpy.props import PointerProperty


class RBDLab_PG_ConstraintsAnimation(PropertyGroup):
    """ context.scene.rbdlab.constraints.animations.x """
    pass